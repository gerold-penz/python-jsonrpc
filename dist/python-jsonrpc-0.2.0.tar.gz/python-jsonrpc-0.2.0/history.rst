#####################################
Python JSON-RPC Library Client Server
#####################################

by Gerold Penz 2013


=============
Version 0.2.1
=============

2013-06-23

- Added a *system.describe*-method (not finished yet)

- Added examples

- Added *parse_json_response*-function


=============
Version 0.2.0
=============

2013-06-23

- Responses module deleted

- *call*-method finished


=============
Version 0.1.1
=============

2013-06-23

- Responses splitted into successful response and errors

- call-function


=============
Version 0.1.0
=============

2013-06-23

- Error module created

- Responses module created

- Base structure


=============
Version 0.0.1
=============

2013-06-23

- Initialy imported
